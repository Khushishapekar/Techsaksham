# NLP Chatbot

## Introduction
A modular system for making chatbots that use a natural langauge model to converse.

Run the discord bot with `python -m discord.main`, or play around with the model on your terminal with `python -m chatbot.gpt2`.

## Requirements
I only made a GPU requirements file, and havn't made a CPU-only one yet. Create a venv using `python -m venv venv`, activate it, and install the requirements file.
