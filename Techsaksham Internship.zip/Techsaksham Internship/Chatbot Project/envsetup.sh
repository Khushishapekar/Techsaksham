#!/bin/bash

source ./venv/bin/activate
export XDG_CACHE_HOME="$HOME/scratch/.cache"

