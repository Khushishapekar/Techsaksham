#!/bin/bash

source ./envsetup.sh

python3 -m discord.main
